<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LokingLanguage extends Model
{
    //
    protected $table='loking_languages';
    protected $PrimaryKey='lang_id';
}
