<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class customer_query extends Model
{
    //
    protected $primaryKey = 'customer_queries_id';
}
