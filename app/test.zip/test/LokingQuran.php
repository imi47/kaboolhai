<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LokingQuran extends Model
{
    //
    protected $primaryKey='loking_read_quran_id';
    protected $table='loking_qurans';
}
