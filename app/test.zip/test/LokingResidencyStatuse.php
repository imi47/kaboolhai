<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LokingResidencyStatuse extends Model
{
    //
     Protected $primaryKey='loking_residency_status_id';
     Protected $table='loking_residency_status';
}
