<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LokingMartialStatus extends Model
{
    //
    protected $primaryKey = 'loking_martial_status_id';
    protected $table = 'loking_martial_status';
}
