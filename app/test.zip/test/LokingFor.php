<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LokingFor extends Model
{
    //
    Protected $primaryKey='loking_id';
}
