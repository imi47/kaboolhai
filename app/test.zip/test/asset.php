<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class asset extends Model
{
    //
      protected $table = 'assets';
      protected $primaryKey = 'asset_id';

    
}
