<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LokingPrays extends Model
{
    //
    protected $PrimaryKey='loking_pray_id';
    protected $table='loking_pray';

}
