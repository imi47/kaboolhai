<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LokingBodyType extends Model
{
    //
    protected $PrimaryKey='loking_body_type_id';
}
